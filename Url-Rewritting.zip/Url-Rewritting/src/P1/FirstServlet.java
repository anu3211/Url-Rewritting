package P1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FirstServlet
 */
public class FirstServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String n=request.getParameter("pinCode");
		out.print("Pincode is-->> "+n+"</br>");

		//appending the pincode in the query string
		String tech= (String)request.getParameter("technology");
        out.println("Technology is-->> "+tech+"</br>");
        out.println("<a href='servlet2?pincode="+n+"&&technology="+tech+"'>Get Job</a>");  
				
		out.close();
}
}
